package com.example.navigatingscreen

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
